clc;
clear all; 
close all; 
a=imread('please.png'); 
%Write an image 
imwrite(a,'please.png') 
% Display an image 
imshow(a) 
figure 
imshow('please.png')