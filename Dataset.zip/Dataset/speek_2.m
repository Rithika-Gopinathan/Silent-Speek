% SILENT SPEAK - Text to Sign Language Display (with folder name "dataset")

% Step 1: Create a dictionary to map words to sign images
signDict = containers.Map;
signDict('hello') = 'dataset/hello.png';
signDict('thank you') = 'dataset/thank you.png';
signDict('please') = 'dataset/please.png';
signDict('sorry') = 'dataset/sorry.png';
signDict('goodbye') = 'dataset/goodbye.png';


% Step 2: Get user input
inputWord = lower(input('Enter your word : ', 's'));

% Step 3: Check if the word exists in the dictionary
if isKey(signDict, inputWord)
    imagePath = signDict(inputWord);    % Get the correct image path
    img = imread(imagePath);             % Read the image
    img = imresize(img, [400 400]);      % Resize the image to 400x400
    imshow(img);
    title(['Sign for "', inputWord, '"']);
else
    disp("Sorry, no sign found for: " + inputWord);
end