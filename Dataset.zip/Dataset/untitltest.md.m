clc 
clear all 
close all 
a=imread("hello.png"); 
%Write an image 
imwrite(a,"hello.png") 
% Display an image 
imshow(a) 
figure 
imshow("hello.png")